package examen.practico;

public class main {

	public static void main(String[] args) {
		Estudiante[] estudiante= new Estudiante[6];
		estudiante[0]= new Estudiante("catalina", "30");
		estudiante[1]= new Estudiante("gabriela", "10");
		estudiante[2]= new Estudiante("natalia", "18");
		estudiante[3]= new Estudiante("angela", "30");
		estudiante[4]= new Estudiante("javier", "60");
		estudiante[5]= new Estudiante("filomena", "5");


		Profesor profesor = new Profesor("eduardo", "56");
		Grupo grupo = new Grupo(profesor, estudiante);
		grupo.calificar();
		grupo.obtDetalles();
		

	}

}
